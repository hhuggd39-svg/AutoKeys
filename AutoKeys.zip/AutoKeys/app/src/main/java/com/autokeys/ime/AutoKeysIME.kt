package com.autokeys.ime

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import com.autokeys.R
import com.autokeys.data.AutoKeysRepository
import com.autokeys.data.LineEntity
import com.autokeys.data.SettingsKeys
import kotlinx.coroutines.*

class AutoKeysIME : InputMethodService() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var repo: AutoKeysRepository

    // State
    private var isAutoEnabled = false
    private var isTyping = false
    private var lines = mutableListOf<LineEntity>()
    private var currentLineIndex = 0
    private var typingJob: Job? = null
    private var triggerWord = "اقوم الحين"
    private var typingSpeed = 100L // ms per character
    private var currentInput = StringBuilder()
    private var pendingRepeat = mutableMapOf<Int, String>() // position -> word

    // Views
    private lateinit var rootView: View
    private lateinit var keyboardLayout: LinearLayout
    private lateinit var btnToggleAuto: Button
    private lateinit var tvStatus: TextView
    private lateinit var etTestArea: EditText

    override fun onCreate() {
        super.onCreate()
        repo = AutoKeysRepository(this)
        loadSettings()
    }

    private fun loadSettings() {
        scope.launch {
            triggerWord = repo.getSetting(SettingsKeys.TRIGGER_WORD, "اقوم الحين")
            typingSpeed = repo.getSetting(SettingsKeys.TYPING_SPEED, "100").toLongOrNull() ?: 100L
            isAutoEnabled = repo.getSetting(SettingsKeys.AUTO_MODE_ENABLED, "false") == "true"
            lines = repo.getAllLines().toMutableList()
        }
    }

    override fun onCreateInputView(): View {
        rootView = LayoutInflater.from(this).inflate(R.layout.keyboard_view, null)
        setupKeyboard()
        return rootView
    }

    private fun setupKeyboard() {
        keyboardLayout = rootView.findViewById(R.id.keyboardLayout)
        btnToggleAuto = rootView.findViewById(R.id.btnToggleAuto)
        tvStatus = rootView.findViewById(R.id.tvStatus)

        // Toggle auto mode
        btnToggleAuto.setOnClickListener {
            isAutoEnabled = !isAutoEnabled
            updateToggleButton()
            scope.launch {
                repo.setSetting(SettingsKeys.AUTO_MODE_ENABLED, isAutoEnabled.toString())
            }
        }

        // Arabic keyboard rows
        setupArabicRows()
        setupSpecialRows()

        updateToggleButton()
        refreshLines()
    }

    private fun updateToggleButton() {
        if (isAutoEnabled) {
            btnToggleAuto.text = "⏹ إيقاف الأوتو"
            btnToggleAuto.setBackgroundColor(Color.parseColor("#FF3B30"))
        } else {
            btnToggleAuto.text = "▶ تشغيل الأوتو"
            btnToggleAuto.setBackgroundColor(Color.parseColor("#34C759"))
        }
    }

    private fun refreshLines() {
        scope.launch {
            lines = repo.getAllLines().toMutableList()
            tvStatus.text = if (lines.isEmpty()) "لا يوجد سطور - أضف من الإعدادات"
            else "سطور: ${lines.size} | الحالي: ${currentLineIndex + 1}"
        }
    }

    private fun setupArabicRows() {
        val arabicRows = listOf(
            listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"),
            listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"),
            listOf("ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ"),
            listOf("⌫", "ذ", "ي", "و", "لا", " ", ".", "،", "؟", "!")
        )

        val keyboardContainer = rootView.findViewById<LinearLayout>(R.id.arabicKeysContainer)

        arabicRows.forEach { row ->
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(2, 2, 2, 2) }
            }

            row.forEach { char ->
                val btn = Button(this).apply {
                    text = char
                    textSize = if (char == " ") 10f else 14f
                    setTextColor(Color.WHITE)
                    setPadding(4, 8, 4, 8)
                    setBackgroundResource(R.drawable.key_background)
                    layoutParams = LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                    ).apply { setMargins(2, 2, 2, 2) }

                    setOnClickListener {
                        when (char) {
                            "⌫" -> handleBackspace()
                            " " -> handleCharInput(" ")
                            else -> handleCharInput(char)
                        }
                    }
                }
                rowLayout.addView(btn)
            }
            keyboardContainer.addView(rowLayout)
        }
    }

    private fun setupSpecialRows() {
        // Numbers row
        val numbersContainer = rootView.findViewById<LinearLayout>(R.id.numbersContainer)
        val numbers = listOf("1","2","3","4","5","6","7","8","9","0","+","-","@","#")
        numbers.forEach { num ->
            val btn = Button(this).apply {
                text = num
                textSize = 12f
                setTextColor(Color.WHITE)
                setBackgroundResource(R.drawable.key_background_special)
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                ).apply { setMargins(2, 2, 2, 2) }
                setOnClickListener { handleCharInput(num) }
            }
            numbersContainer.addView(btn)
        }

        // Decoration buttons
        val decorContainer = rootView.findViewById<LinearLayout>(R.id.decorContainer)
        val decorChars = listOf("\"", "'", "~", "•", "×", "_", "=", "^", "<", ">", "\\")
        decorChars.forEach { d ->
            val btn = Button(this).apply {
                text = d
                textSize = 14f
                setTextColor(Color.parseColor("#FFD700"))
                setBackgroundResource(R.drawable.key_background_decor)
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                ).apply { setMargins(2, 2, 2, 2) }
                setOnClickListener { handleDecoration(d) }
            }
            decorContainer.addView(btn)
        }
    }

    private fun handleCharInput(char: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(char, 1)
        currentInput.append(char)

        // Check for repeat pattern like كلمة(3)
        checkRepeatPattern()

        // Check for trigger word
        if (isAutoEnabled && currentInput.toString().contains(triggerWord)) {
            val idx = currentInput.indexOf(triggerWord)
            if (idx >= 0) {
                currentInput.delete(idx, idx + triggerWord.length)
                startAutoTyping()
            }
        }
    }

    private fun checkRepeatPattern() {
        val text = currentInput.toString()
        // Pattern: word(N) - repeat word N times
        val pattern = Regex("""(\S+)\((\d+)\)""")
        val match = pattern.find(text) ?: return

        val word = match.groupValues[1]
        val count = match.groupValues[2].toIntOrNull() ?: return

        if (count > 1) {
            val ic = currentInputConnection ?: return
            // Delete the pattern
            val fullMatch = match.value
            repeat(fullMatch.length) {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            }
            // Type the word N times
            val repeated = List(count) { word }.joinToString(" ")
            ic.commitText(repeated, 1)
            currentInput.clear()
            currentInput.append(text.substring(0, match.range.first))
            currentInput.append(repeated)
        }
    }

    private fun handleBackspace() {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
        if (currentInput.isNotEmpty()) {
            currentInput.deleteCharAt(currentInput.length - 1)
        }
    }

    private fun handleDecoration(char: String) {
        val ic = currentInputConnection ?: return
        // Get selected text or insert decoration around cursor
        val selected = ic.getSelectedText(0)
        if (selected != null && selected.isNotEmpty()) {
            ic.commitText("$char$selected$char", 1)
        } else {
            ic.commitText(char, 1)
        }
    }

    private fun startAutoTyping() {
        if (lines.isEmpty()) {
            tvStatus.text = "لا يوجد سطور! أضف من الإعدادات"
            return
        }

        typingJob?.cancel()
        isTyping = true

        typingJob = scope.launch {
            val ic = currentInputConnection ?: return@launch

            while (currentLineIndex < lines.size) {
                val line = lines[currentLineIndex]
                val processedText = processLineText(line.text)

                // Type character by character
                for (char in processedText) {
                    if (!isTyping) break
                    ic.commitText(char.toString(), 1)
                    delay(typingSpeed)
                }

                if (!isTyping) break

                // Add newline after each line
                ic.commitText("\n", 1)
                currentLineIndex++

                tvStatus.text = "سطور: ${lines.size} | الحالي: ${currentLineIndex + 1}"
                delay(typingSpeed * 2)
            }

            // Reset when done
            currentLineIndex = 0
            isTyping = false
            tvStatus.text = "اكتمل ✓ | سطور: ${lines.size}"
        }
    }

    // Process text: remove punctuation repeats, handle special patterns
    private fun processLineText(text: String): String {
        // Remove leading/trailing punctuation duplicates
        return text.trim()
    }

    fun stopAutoTyping() {
        typingJob?.cancel()
        isTyping = false
        currentLineIndex = 0
        tvStatus.text = "متوقف | سطور: ${lines.size}"
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        currentInput.clear()
        refreshLines()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
