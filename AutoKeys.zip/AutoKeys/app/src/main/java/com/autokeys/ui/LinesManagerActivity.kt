package com.autokeys.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.autokeys.R
import com.autokeys.data.AutoKeysRepository
import com.autokeys.data.LineEntity
import kotlinx.coroutines.launch

class LinesManagerActivity : AppCompatActivity() {

    private lateinit var repo: AutoKeysRepository
    private lateinit var adapter: LinesAdapter
    private val lines = mutableListOf<LineEntity>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lines_manager)
        repo = AutoKeysRepository(this)

        setupRecyclerView()
        setupAddLine()
        setupImportLines()
        loadLines()
    }

    private fun setupRecyclerView() {
        adapter = LinesAdapter(lines) { line ->
            // Delete line
            AlertDialog.Builder(this)
                .setTitle("حذف السطر")
                .setMessage("هل تريد حذف: ${line.text.take(30)}?")
                .setPositiveButton("حذف") { _, _ ->
                    lifecycleScope.launch {
                        repo.deleteLine(line)
                        loadLines()
                    }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        val rv = findViewById<RecyclerView>(R.id.rvLines)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
    }

    private fun setupAddLine() {
        val etLine = findViewById<EditText>(R.id.etNewLine)
        val btnAdd = findViewById<Button>(R.id.btnAddLine)

        btnAdd.setOnClickListener {
            val text = etLine.text.toString().trim()
            if (text.isNotEmpty()) {
                lifecycleScope.launch {
                    repo.insertLine(text)
                    runOnUiThread {
                        etLine.text.clear()
                        Toast.makeText(this@LinesManagerActivity, "تمت الإضافة ✓", Toast.LENGTH_SHORT).show()
                    }
                    loadLines()
                }
            }
        }
    }

    private fun setupImportLines() {
        val btnImport = findViewById<Button>(R.id.btnImportLines)
        btnImport.setOnClickListener {
            val dialog = AlertDialog.Builder(this)
            val editText = EditText(this).apply {
                hint = "الصق السطور هنا (كل سطر منفصل)"
                minLines = 5
                maxLines = 15
                setPadding(32, 16, 32, 16)
            }
            AlertDialog.Builder(this)
                .setTitle("استيراد سطور")
                .setView(editText)
                .setPositiveButton("استيراد") { _, _ ->
                    val text = editText.text.toString()
                    val newLines = text.split("\n").filter { it.trim().isNotEmpty() }
                    lifecycleScope.launch {
                        newLines.forEach { repo.insertLine(it.trim()) }
                        runOnUiThread {
                            Toast.makeText(this@LinesManagerActivity,
                                "تم استيراد ${newLines.size} سطر ✓",
                                Toast.LENGTH_SHORT).show()
                        }
                        loadLines()
                    }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }
    }

    private fun loadLines() {
        lifecycleScope.launch {
            val all = repo.getAllLines()
            runOnUiThread {
                lines.clear()
                lines.addAll(all)
                adapter.notifyDataSetChanged()
                findViewById<TextView>(R.id.tvLinesCount).text = "إجمالي السطور: ${all.size}"
            }
        }
    }
}

// RecyclerView Adapter
class LinesAdapter(
    private val lines: List<LineEntity>,
    private val onDelete: (LineEntity) -> Unit
) : RecyclerView.Adapter<LinesAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val tvText: TextView = view.findViewById(R.id.tvLineText)
        val tvIndex: TextView = view.findViewById(R.id.tvLineIndex)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDeleteLine)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val v = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_line, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val line = lines[position]
        holder.tvIndex.text = "${position + 1}"
        holder.tvText.text = line.text
        holder.btnDelete.setOnClickListener { onDelete(line) }
    }

    override fun getItemCount() = lines.size
}
