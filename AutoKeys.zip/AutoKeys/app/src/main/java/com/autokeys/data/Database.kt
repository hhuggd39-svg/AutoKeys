package com.autokeys.data

import androidx.room.*

// ===== ENTITIES =====

@Entity(tableName = "lines")
data class LineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val orderIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

// ===== DAOs =====

@Dao
interface LineDao {
    @Query("SELECT * FROM lines ORDER BY orderIndex ASC")
    suspend fun getAllLines(): List<LineEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLine(line: LineEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLines(lines: List<LineEntity>)

    @Delete
    suspend fun deleteLine(line: LineEntity)

    @Query("DELETE FROM lines")
    suspend fun deleteAllLines()

    @Query("SELECT COUNT(*) FROM lines")
    suspend fun getCount(): Int

    @Update
    suspend fun updateLine(line: LineEntity)
}

@Dao
interface SettingDao {
    @Query("SELECT value FROM settings WHERE `key` = :key")
    suspend fun getValue(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setValue(setting: SettingEntity)

    @Query("SELECT * FROM settings")
    suspend fun getAllSettings(): List<SettingEntity>
}

// ===== DATABASE =====

@Database(entities = [LineEntity::class, SettingEntity::class], version = 1)
abstract class AutoKeysDatabase : RoomDatabase() {
    abstract fun lineDao(): LineDao
    abstract fun settingDao(): SettingDao

    companion object {
        @Volatile private var INSTANCE: AutoKeysDatabase? = null

        fun getInstance(context: android.content.Context): AutoKeysDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AutoKeysDatabase::class.java,
                    "autokeys_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

// ===== REPOSITORY =====

class AutoKeysRepository(context: android.content.Context) {
    private val db = AutoKeysDatabase.getInstance(context)
    private val lineDao = db.lineDao()
    private val settingDao = db.settingDao()

    suspend fun getAllLines() = lineDao.getAllLines()
    suspend fun insertLine(text: String) {
        val count = lineDao.getCount()
        lineDao.insertLine(LineEntity(text = text, orderIndex = count))
    }
    suspend fun deleteLine(line: LineEntity) = lineDao.deleteLine(line)
    suspend fun deleteAllLines() = lineDao.deleteAllLines()
    suspend fun updateLine(line: LineEntity) = lineDao.updateLine(line)

    suspend fun getSetting(key: String, default: String = ""): String =
        settingDao.getValue(key) ?: default

    suspend fun setSetting(key: String, value: String) =
        settingDao.setValue(SettingEntity(key, value))
}

// ===== SETTINGS KEYS =====
object SettingsKeys {
    const val TRIGGER_WORD = "trigger_word"
    const val AUTO_MODE_ENABLED = "auto_mode_enabled"
    const val AI_MODE_ENABLED = "ai_mode_enabled"
    const val KEYBOARD_HEIGHT = "keyboard_height"
    const val TYPING_SPEED = "typing_speed"
    const val BACKGROUND_COLOR = "background_color"
    const val BACKGROUND_IMAGE = "background_image"
    const val KEY_COLOR = "key_color"
    const val TEXT_COLOR = "text_color"
    const val REPEAT_MODE = "repeat_mode"
    const val DECORATION_CHAR = "decoration_char"
    const val AI_API_KEY = "ai_api_key"
}
