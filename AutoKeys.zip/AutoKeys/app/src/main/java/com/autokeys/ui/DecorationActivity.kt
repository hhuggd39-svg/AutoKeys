package com.autokeys.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.autokeys.R

class DecorationActivity : AppCompatActivity() {

    private val decorChars = listOf("\"", "'", "~", "•", "×", "_", "=", "^", "<", ">", "\\")
    private var selectedDecor = "•"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decoration)
        setupDecorations()
    }

    private fun setupDecorations() {
        val container = findViewById<LinearLayout>(R.id.decorButtonsContainer)
        val etPreview = findViewById<EditText>(R.id.etDecorationPreview)
        val tvResult = findViewById<TextView>(R.id.tvDecorationResult)

        // Example text
        val sampleWords = listOf("وش", "تبي", "الحين", "يعني", "اصمل", "معي")

        decorChars.forEach { char ->
            val btn = Button(this).apply {
                text = char
                textSize = 20f
                setOnClickListener {
                    selectedDecor = char
                    updatePreview(etPreview.text.toString(), char, sampleWords, tvResult)
                }
            }
            container.addView(btn)
        }

        etPreview.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                updatePreview(s.toString(), selectedDecor, sampleWords, tvResult)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Default preview
        updatePreview("", selectedDecor, sampleWords, tvResult)
    }

    private fun updatePreview(
        customText: String,
        decor: String,
        words: List<String>,
        tvResult: TextView
    ) {
        val wordsToUse = if (customText.trim().isNotEmpty()) {
            customText.trim().split(" ").filter { it.isNotEmpty() }
        } else words

        val decorated = wordsToUse.joinToString(" $decor ") { it }
        tvResult.text = decorated
    }
}
