package com.autokeys.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.autokeys.R
import com.autokeys.data.AutoKeysRepository
import com.autokeys.data.SettingsKeys
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var repo: AutoKeysRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        repo = AutoKeysRepository(this)

        setupUI()
        loadSettings()
    }

    private fun setupUI() {
        // Enable Keyboard button
        findViewById<Button>(R.id.btnEnableKeyboard).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        // Select Keyboard button
        findViewById<Button>(R.id.btnSelectKeyboard).setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        // Lines Manager
        findViewById<Button>(R.id.btnManageLines).setOnClickListener {
            startActivity(Intent(this, LinesManagerActivity::class.java))
        }

        // Decoration
        findViewById<Button>(R.id.btnDecoration).setOnClickListener {
            startActivity(Intent(this, DecorationActivity::class.java))
        }

        // Save Settings
        findViewById<Button>(R.id.btnSaveSettings).setOnClickListener {
            saveSettings()
        }

        // Speed slider
        val speedSlider = findViewById<SeekBar>(R.id.seekBarSpeed)
        val tvSpeedValue = findViewById<TextView>(R.id.tvSpeedValue)
        speedSlider.max = 990
        speedSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = (progress + 10).toFloat() / 10f // 1ms to 100ms
                tvSpeedValue.text = "${speed}x"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun loadSettings() {
        lifecycleScope.launch {
            val trigger = repo.getSetting(SettingsKeys.TRIGGER_WORD, "اقوم الحين")
            val speed = repo.getSetting(SettingsKeys.TYPING_SPEED, "100").toIntOrNull() ?: 100
            val autoEnabled = repo.getSetting(SettingsKeys.AUTO_MODE_ENABLED, "false") == "true"
            val aiEnabled = repo.getSetting(SettingsKeys.AI_MODE_ENABLED, "false") == "true"
            val kbHeight = repo.getSetting(SettingsKeys.KEYBOARD_HEIGHT, "250").toIntOrNull() ?: 250

            runOnUiThread {
                findViewById<EditText>(R.id.etTriggerWord).setText(trigger)
                findViewById<SeekBar>(R.id.seekBarSpeed).progress = (speed - 10).coerceIn(0, 990)
                findViewById<Switch>(R.id.switchAutoMode).isChecked = autoEnabled
                findViewById<Switch>(R.id.switchAIMode).isChecked = aiEnabled
                findViewById<EditText>(R.id.etKeyboardHeight).setText(kbHeight.toString())
            }
        }
    }

    private fun saveSettings() {
        val trigger = findViewById<EditText>(R.id.etTriggerWord).text.toString()
        val speedProgress = findViewById<SeekBar>(R.id.seekBarSpeed).progress
        val speed = speedProgress + 10
        val autoEnabled = findViewById<Switch>(R.id.switchAutoMode).isChecked
        val aiEnabled = findViewById<Switch>(R.id.switchAIMode).isChecked
        val kbHeight = findViewById<EditText>(R.id.etKeyboardHeight).text.toString()

        lifecycleScope.launch {
            repo.setSetting(SettingsKeys.TRIGGER_WORD, trigger.ifEmpty { "اقوم الحين" })
            repo.setSetting(SettingsKeys.TYPING_SPEED, speed.toString())
            repo.setSetting(SettingsKeys.AUTO_MODE_ENABLED, autoEnabled.toString())
            repo.setSetting(SettingsKeys.AI_MODE_ENABLED, aiEnabled.toString())
            repo.setSetting(SettingsKeys.KEYBOARD_HEIGHT, kbHeight.ifEmpty { "250" })

            runOnUiThread {
                Toast.makeText(this@MainActivity, "تم الحفظ ✓", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
